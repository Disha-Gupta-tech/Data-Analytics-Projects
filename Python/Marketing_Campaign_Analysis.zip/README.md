# Marketing Campaign Analysis Package

## Included
- Original Jupyter notebook: `Marketing Campaign Analysis.ipynb`
- `charts/`: 43 saved chart images extracted from notebook outputs.
- `tables/`: 15 tables extracted as CSV files, plus a combined Excel workbook if available.
- `reports/`: HTML notebook export and PDF narrative report if export succeeded.

## Dataset note
The notebook refers to `marketing_campaign.csv` in a local Desktop folder. That CSV was not among the uploaded files, so it is not included. The available charts and tables were extracted from the notebook's saved outputs. To rerun all cells, provide the CSV and update the file path in the notebook if needed.
